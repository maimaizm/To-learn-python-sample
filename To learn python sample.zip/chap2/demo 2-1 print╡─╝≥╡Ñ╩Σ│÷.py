a=114514 #a的值为114514
b=1919810 #b的值为1919810
print(100)
print(a+b)
print(a*b)

print('你好')
#print的格式(value,...,sep='',end='\n',file=none)