print(ord('你')) #ord可以查看字符的ask i i值
print(ord('好'))
print(chr(20320),chr(22909))