#无需缩进代码
print(chr(11))
#类的定义需要
class student:
    pass
#函数的定义需要
def fun():
    pass
