a=open('note.txt','w') #打开记事本note
print(chr(20320),chr(22909),file=a) #在note里使用Unicode输出你好
b=114514
c=1919810
print(b+c,file=a) #在note里输出114514+1919810的结果
a.close() #关闭close