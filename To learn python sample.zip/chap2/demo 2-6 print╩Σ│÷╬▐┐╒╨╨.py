print('你好',end='-')
print('hello word') #结尾未修改结束符因此生成空行