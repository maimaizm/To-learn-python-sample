print('b')
print(chr(98)) #chr输出ask i i的unicode值
print('C')
print(chr(67))
print('$')
print(chr(36))
#中文ask i i范围u4e00~u9fa5