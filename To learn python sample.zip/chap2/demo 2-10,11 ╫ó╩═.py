#coding=utf-8
#中文声明注释
'''
python
可以
多行
注释
'''
"""
多行
注释
方法
2
"""
print('hello word') #也可以单行注释