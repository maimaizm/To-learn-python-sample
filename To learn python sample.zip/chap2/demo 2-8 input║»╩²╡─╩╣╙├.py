name=input('输入您的姓名：')
print('您的姓名是'+name)
#input格式:variable=input('提示文字')