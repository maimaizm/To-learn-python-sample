a=open('note2.txt','w')
print('你好'+'2024',end='-',file=a) #只能字符串和字符串链接
a.close()