a=open('text.txt','w')
print('人生苦短，我用python',file=a)
a.close()