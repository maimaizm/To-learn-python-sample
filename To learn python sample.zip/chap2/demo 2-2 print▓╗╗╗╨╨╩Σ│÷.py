a=114514 #a为114514
b=1919810 #b为1919810
print(a,b,'hello word')