num=input('输入您的幸运数字')
num=int(num) #使用int将字符转换为整数
print('您的幸运数字',end='：')
print(num)